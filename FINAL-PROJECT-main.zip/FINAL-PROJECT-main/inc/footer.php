<!-- footer.php -->
<footer>
    <div class="footer-content">
        <!-- Logo -->
        <div class="footer-logo">
            <img src="img/user.jpg" alt="TimeWise Logo">
        </div>

        <!-- Copyright Text -->
        <div class="footer-text">
            <p>&copy; 2024 TimeWise. All rights reserved. Time Management System</p>
        </div>
    </div>
</footer>
